#!/usr/bin/env bash

apt-get -y update

apt-get install postgresql postgresql-contrib